// src/rides/rides.controller.ts
import { Controller, Post, Get, Patch, Param, Body, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { RidesService } from './rides.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Rides')
@ApiBearerAuth()
@Controller('rides')
@UseGuards(JwtAuthGuard)
export class RidesController {
  constructor(private readonly ridesService: RidesService) {}

  // === PASSAGER ===
  @Post()
  createRide(@Request() req: any, @Body() body: any) {
    return this.ridesService.createRide(req.user.id, body);
  }

  // === CHAUFFEUR ===
  @Get('available')
  getAvailableRides(@Request() req: any) {
    return this.ridesService.getAvailableRides(req.user.id);
  }

  @Post(':id/accept')
  acceptRide(@Request() req: any, @Param('id') rideId: string) {
    return this.ridesService.acceptRide(rideId, req.user.id);
  }

  @Patch(':id/status')
  updateStatus(@Param('id') rideId: string, @Body() body: { status: string; cancelReason?: string }) {
    return this.ridesService.updateRideStatus(rideId, body.status, body.cancelReason);
  }

  @Post(':id/verify-pin')
  verifyPin(@Param('id') rideId: string, @Body() body: { pin: string }) {
    return this.ridesService.verifyPin(rideId, body.pin);
  }

  // Historique
  @Get('me')
  getMyRides(@Request() req: any) {
    return this.ridesService.getUserRides(req.user.id);
  }
}