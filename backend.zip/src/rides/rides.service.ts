// src/rides/rides.service.ts
import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AppGateway } from '../common/websocket.gateway';

@Injectable()
export class RidesService {
  constructor(
    private prisma: PrismaService,
    private gateway: AppGateway,
  ) {}

  // PASSAGER : Créer une course
  async createRide(passengerId: string, data: any) {
    const ride = await this.prisma.ride.create({
      data: {
        passengerId,
        pickupLat: data.pickupLat,
        pickupLng: data.pickupLng,
        pickupAddress: data.pickupAddress,
        dropoffLat: data.dropoffLat,
        dropoffLng: data.dropoffLng,
        dropoffAddress: data.dropoffAddress,
        vehicleType: data.vehicleType || 'ECO',
        estimatedPrice: data.estimatedPrice,
        paymentMethod: data.paymentMethod || 'CASH',
        pinCode: Math.floor(100000 + Math.random() * 900000).toString(), // 6 chiffres
        status: 'REQUESTED',
      },
    });

    // Notifier les chauffeurs proches (via WebSocket)
    this.gateway.server.emit('ride:new', ride);

    return ride;
  }

  // CHAUFFEUR : Voir les courses disponibles
  async getAvailableRides(driverId: string) {
    return this.prisma.ride.findMany({
      where: { status: 'REQUESTED' },
      include: { passenger: true },
      orderBy: { requestedAt: 'desc' },
    });
  }

  // CHAUFFEUR : Accepter une course
  async acceptRide(rideId: string, driverId: string) {
    const ride = await this.prisma.ride.findUnique({ where: { id: rideId } });
    if (!ride) throw new NotFoundException('Course introuvable');
    if (ride.status !== 'REQUESTED') throw new BadRequestException('Course déjà prise');

    const updated = await this.prisma.ride.update({
      where: { id: rideId },
      data: {
        driverId,
        status: 'ACCEPTED',
        acceptedAt: new Date(),
      },
    });

    // Notifier TOUT LE MONDE dans la room de la course
    this.gateway.server.to(`ride:${rideId}`).emit('ride:accepted', {
      rideId,
      driverId,
      status: 'ACCEPTED',
    });

    return updated;
  }

  // Mise à jour du statut (chauffeur ou passager)
  async updateRideStatus(rideId: string, status: string, cancelReason?: string) {
    const ride = await this.prisma.ride.update({
      where: { id: rideId },
      data: { 
        status: status as any,
        cancelReason: cancelReason || null,
        ...(status === 'COMPLETED' ? { completedAt: new Date() } : {}),
        ...(status === 'CANCELLED' ? { cancelledAt: new Date() } : {}),
      },
    });

    this.gateway.server.to(`ride:${rideId}`).emit('ride:status', { rideId, status });

    return ride;
  }

  // Vérification du PIN pour démarrer la course
  async verifyPin(rideId: string, pin: string) {
    const ride = await this.prisma.ride.findUnique({ where: { id: rideId } });
    if (!ride) throw new NotFoundException('Course introuvable');
    if (ride.pinCode !== pin) throw new BadRequestException('Code PIN incorrect');

    return this.updateRideStatus(rideId, 'IN_PROGRESS');
  }

  async getUserRides(userId: string) {
    return this.prisma.ride.findMany({
      where: { OR: [{ passengerId: userId }, { driverId: userId }] },
      include: { passenger: true, driver: true },
      orderBy: { requestedAt: 'desc' },
    });
  }
}