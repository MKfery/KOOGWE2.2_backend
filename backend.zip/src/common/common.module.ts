import { Module } from '@nestjs/common';
import { AppGateway } from './websocket.gateway';
import { PrismaService } from '../prisma/prisma.service';

@Module({
  providers: [AppGateway, PrismaService],
  exports: [AppGateway],
})
export class CommonModule {}