// src/common/websocket.gateway.ts
import { WebSocketGateway, WebSocketServer, SubscribeMessage, MessageBody, ConnectedSocket, OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
@WebSocketGateway({
  cors: { origin: '*' },
  namespace: '/',
})
export class AppGateway implements OnGatewayConnection, OnGatewayDisconnect {
  private readonly logger = new Logger(AppGateway.name);
  @WebSocketServer() server: Server;

  constructor(private prisma: PrismaService) {}

  handleConnection(client: Socket) {
    this.logger.log(`Client connecté : ${client.id} | IP: ${client.handshake.address}`);
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client déconnecté : ${client.id}`);
  }

  // ====================== CHAUFFEUR ======================
  @SubscribeMessage('driver:location')
  async handleDriverLocation(
    @ConnectedSocket() client: Socket,
    @MessageBody() data: { lat: number; lng: number; heading?: number; rideId?: string }
  ) {
    const userId = client.handshake.auth?.userId || client.handshake.query?.userId;
    if (!userId) return;

    // Mise à jour en base (pour fallback)
    await this.prisma.driverProfile.update({
      where: { userId },
      data: { currentLat: data.lat, currentLng: data.lng, heading: data.heading, lastLocationAt: new Date() },
    });

    // Broadcast à tous les passagers de la course (si rideId)
    if (data.rideId) {
      this.server.to(`ride:${data.rideId}`).emit('driver:location', {
        driverId: userId,
        lat: data.lat,
        lng: data.lng,
        heading: data.heading,
      });
    }
  }

  @SubscribeMessage('driver:availability')
  handleAvailability(@ConnectedSocket() client: Socket, @MessageBody() data: { availability: 'ONLINE' | 'OFFLINE' }) {
    // Optionnel : tu peux logger ou notifier l'admin
    this.logger.log(`Chauffeur ${client.handshake.auth?.userId} → ${data.availability}`);
  }

  // ====================== PASSAGER / CHAUFFEUR ======================
  @SubscribeMessage('ride:join')
  handleJoinRide(@ConnectedSocket() client: Socket, @MessageBody() data: { rideId: string }) {
    if (!data.rideId) return;
    client.join(`ride:${data.rideId}`);
    this.logger.log(`Client ${client.id} a rejoint la room ride:${data.rideId}`);
  }

  // Le chauffeur accepte une course
  @SubscribeMessage('ride:accept')
  async handleRideAccept(@MessageBody() data: { rideId: string; driverId: string }) {
    // Mise à jour du statut
    await this.prisma.ride.update({
      where: { id: data.rideId },
      data: { driverId: data.driverId, status: 'ACCEPTED', acceptedAt: new Date() },
    });

    // Notifier le passager
    this.server.to(`ride:${data.rideId}`).emit('ride:accepted', {
      rideId: data.rideId,
      driverId: data.driverId,
      status: 'ACCEPTED',
    });
  }

  // Mise à jour du statut de la course
  @SubscribeMessage('ride:status')
  async handleRideStatus(@MessageBody() data: { rideId: string; status: string }) {
    await this.prisma.ride.update({
      where: { id: data.rideId },
      data: { status: data.status as any },
    });

    this.server.to(`ride:${data.rideId}`).emit('ride:status', data);
  }

  // Message chat
  @SubscribeMessage('chat:message')
  handleChatMessage(@MessageBody() data: { rideId: string; content: string; senderId: string }) {
    this.server.to(`ride:${data.rideId}`).emit('chat:message', data);
  }
}