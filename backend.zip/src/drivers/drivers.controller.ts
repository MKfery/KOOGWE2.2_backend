// src/drivers/drivers.controller.ts
import { Controller, Get, Post, Patch, Body, Req, Query, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { DriversService } from './drivers.service';
import { FaceVerificationService } from '../face-verification/face-verification.service';
import { Roles, RolesGuard, JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Drivers')
@ApiBearerAuth()
@Controller('drivers')
@UseGuards(JwtAuthGuard)   // Protection JWT sur tout le controller
export class DriversController {
  constructor(
    private readonly driversService: DriversService,
    private readonly faceVerificationService: FaceVerificationService,   // ← Injecté
  ) {}

  // ─────────────────────────────────────────────────────────────────────────
  // PROFIL CHAUFFEUR
  // ─────────────────────────────────────────────────────────────────────────
  @Post('profile')
  @ApiOperation({ summary: 'Créer ou mettre à jour le profil chauffeur' })
  createProfile(@Req() req: any, @Body() dto: any) {
    return this.driversService.createProfile(req.user.id, dto);
  }

  @Get('profile')
  @ApiOperation({ summary: 'Obtenir son profil chauffeur' })
  getProfile(@Req() req: any) {
    return this.driversService.getProfile(req.user.id);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // VÉRIFICATION FACIALE (Nouvelle route principale)
  // ─────────────────────────────────────────────────────────────────────────
  @Post('verify-face')
  @ApiOperation({
    summary: 'Vérification faciale du chauffeur',
    description: 'Envoie une photo selfie en base64 pour valider l\'identité du chauffeur.'
  })
  @ApiResponse({
    status: 200,
    description: 'Vérification faciale réussie',
  })
  async verifyFace(@Req() req: any, @Body() body: { imageBase64: string }) {
    return this.faceVerificationService.verifyFace(req.user.id, body.imageBase64);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // DISPONIBILITÉ & LOCALISATION
  // ─────────────────────────────────────────────────────────────────────────
  @Patch('availability')
  @ApiOperation({ summary: 'Passer en ligne / hors ligne' })
  updateAvailability(@Req() req: any, @Body() dto: any) {
    return this.driversService.updateAvailability(req.user.id, dto);
  }

  @Patch('location')
  @ApiOperation({ summary: 'Mettre à jour la position GPS' })
  updateLocation(@Req() req: any, @Body() dto: any) {
    return this.driversService.updateLocation(req.user.id, dto);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // STATISTIQUES & HISTORIQUE
  // ─────────────────────────────────────────────────────────────────────────
  @Get('stats')
  @ApiOperation({ summary: 'Statistiques et gains du chauffeur' })
  getStats(@Req() req: any) {
    return this.driversService.getStats(req.user.id);
  }

  @Get('rides')
  @ApiOperation({ summary: 'Historique des courses du chauffeur' })
  getRides(@Req() req: any, @Query('page') page = '1', @Query('limit') limit = '10') {
    return this.driversService.getRideHistory(req.user.id, +page, +limit);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // DOCUMENTS
  // ─────────────────────────────────────────────────────────────────────────
  @Post('documents')
  @ApiOperation({ summary: 'Enregistrer un document (URL Cloudinary)' })
  uploadDocument(
    @Req() req: any,
    @Body('type') type: string,
    @Body('fileUrl') fileUrl: string,
  ) {
    return this.driversService.uploadDocument(req.user.id, type, fileUrl);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // ROUTES ADMIN SEULEMENT
  // ─────────────────────────────────────────────────────────────────────────
  @Get('admin/pending')
  @Roles('ADMIN')
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: '[ADMIN] Liste des chauffeurs en attente' })
  getPendingDrivers() {
    return this.driversService.getPendingDrivers();
  }

  @Patch('admin/:id/approve')
  @Roles('ADMIN')
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: '[ADMIN] Approuver un chauffeur' })
  approveDriver(@Param('id') id: string) {
    return this.driversService.approveDriver(id);
  }

  @Patch('admin/:id/reject')
  @Roles('ADMIN')
  @UseGuards(RolesGuard)
  @ApiOperation({ summary: '[ADMIN] Rejeter un chauffeur' })
  rejectDriver(@Param('id') id: string, @Body('reason') reason?: string) {
    return this.driversService.rejectDriver(id, reason);
  }

  // Optionnel : Statut de la vérification faciale
  @Get('face-status')
  @ApiOperation({ summary: 'Récupérer le statut de vérification faciale' })
  getFaceStatus(@Req() req: any) {
    return this.faceVerificationService.getFaceVerificationStatus(req.user.id);
  }
}