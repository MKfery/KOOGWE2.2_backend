// src/mail/mail.service.ts (version Resend)
import { Injectable, Logger } from '@nestjs/common';
import { Resend } from 'resend';

@Injectable()
export class MailService {
  private resend: Resend;
  private logger = new Logger('MailService');

  constructor() {
    this.resend = new Resend(process.env.RESEND_API_KEY);
  }

  async sendOtp(email: string, code: string, language = 'fr') {
    const subject = language === 'fr' ? 'Votre code Koogwe' : 'Your Koogwe verification code';
    await this.resend.emails.send({
      from: 'Koogwe <noreply@koogwe.com>',
      to: email,
      subject,
      html: `
        <h1>${code}</h1>
        <p>Ce code expire dans 10 minutes.</p>
      `,
    });
    this.logger.log(`OTP envoyé à ${email}`);
  }
}